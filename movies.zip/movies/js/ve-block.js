wp.blocks.registerBlockType('ve/custom-block',{
    title: 'Favorite movie quote',
    icon: 'format-quote',
    category: 'text',
    attributes: {
        favQuote: { type: 'string' },
    },
    edit: function(props){
        
        function updateFavQuote(event){ props.setAttributes({favQuote: event.target.value }) }
        
        
        return React.createElement("div", null, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", null, "Favorite Movie Quote"), /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("input", {
            type: "text",
            value: props.attributes.companyName,
            placeholder: "A rememberable line...",
            onChange: updateFavQuote
          })),
        );
    },
    save: function(props){
        return React.createElement("div", null, /*#__PURE__*/React.createElement("h6", null, "Here is the Favorite Movie Quote:"),React.createElement("h3", null, props.attributes.favQuote));
    }


    // A Confession_comment: I do not really do React, but I've found a site that converts HTML to React, and it worked! :)
})