<?php
/*
Plugin Name: Movies
 * Plugin URI:        
 * Description:       Description...
 * Version:           1.0
 * Author:            Vladimir Eric
 * Author URI:        
 * Textdomain:       movies
 * Domain Path:       
 * GitHub Plugin URI: https://github.com/lezgubeaux/q_agency
*/ 



define( 'POSTS_BY_DATE_PLUGIN_URL', WP_PLUGIN_URL . '/movies' );



// registering custom post type Movies
function ve_register_post_type() {

    $labels = array(
        'name' => __( 'Movies', 'movies' ),
        'singular_name' => __( 'Movie', 'movies' ),
        'add_new' => __( 'New Movie', 'movies' ),
        'add_new_item' => __( 'Add New Movie', 'movies' ),
        'edit_item' => __( 'Edit Movie', 'movies' ),
        'new_item' => __( 'New Movie', 'movies' ),
        'view_item' => __( 'View Movies', 'movies' ),
        'search_items' => __( 'Search Movies', 'movies' ),
        'not_found' =>  __( 'No Movies Found', 'movies' ),
        'not_found_in_trash' => __( 'No Movies found in Trash', 'movies' ),
    );

    $args = array(
        'labels' => $labels,
        'has_archive' => true,
        'public' => true,
        'hierarchical' => false,
        'supports' => array(
            'title',
            'editor',
            'excerpt',
            'custom-fields',
            'thumbnail',
            'page-attributes'
        ),
        'rewrite'   => array( 'slug' => 'movie' ),
        'show_in_rest' => true,
    );

    register_post_type( 'movies', $args );

}
add_action( 'init', 've_register_post_type' );



// adding post meta field Title
function ve_admin_init(){
    add_meta_box('movie_title-meta', 'Movie Title', 'movie_title', 'movies', 'normal', 'low');
}
add_action('admin_init', 've_admin_init');

function movie_title(){    
  global $post;
  $custom = get_post_custom($post->ID);
  $movie_title = $custom['movie_title'][0];
  ?>
  <input name='movie_title' value='<?php echo $movie_title; ?>' />
  <?php
}

function save_details(){
    global $post;  
    update_post_meta($post->ID, 'movie_title', $_POST['movie_title']);
}
add_action('save_post', 'save_details');



// Gutenberg custom block
function ve_custom_block_script_register() {
    wp_enqueue_script('ve-custom-block',POSTS_BY_DATE_PLUGIN_URL.'/js/ve-block.js',array('wp-blocks','wp-i18n','wp-editor'),true,false);
}
add_action('enqueue_block_editor_assets','ve_custom_block_script_register');