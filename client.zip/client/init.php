<?php
/*
 * Plugin Name:       Client
 * Plugin URI:        
 * Description:       Description: Plugin allows user to insert API credentials, and if connected, stores the token in a cookie.
 * Version:           1.0
 * Author:            Vladimir Eric
 * Author URI:        
 * Text Domain:       client
*/ 



define( 'CLIENT_PLUGIN_URL', WP_PLUGIN_URL . '/client' );



class Client {



    // plugin basics #####################################################
    protected $pluginPath;
    protected $pluginUrl;



    // shortcode #####################################################
    public function __construct(){
        // Set Plugin Path
        $this->pluginPath = dirname(__FILE__);     
        // Set Plugin URL
        $this->pluginUrl = WP_PLUGIN_URL . '/client';
    }
     
}

$client = new Client();



/*
// load assets #######################################################
function posts_by_date_enqueue_assets() {
}
add_action( 'wp_enqueue_scripts', 'posts_by_date_enqueue_assets');*/



// settings page ########################################################
// admin menu item
function client_add_settings_page() {
    add_options_page( 
        'Client SETTINGS',                // title tag
        'Client',                         // menu label
        'manage_options',                       // user capability (admin)
        'client-plugin',                           // menu slug
        'client_render_plugin_settings_page' 
    );    // function => page content
}
add_action( 'admin_menu', 'client_add_settings_page' );    // fires 1st (before admin_init)

// set the cookie from options
function set_q_cookie(){
    $options = get_option( 'client_plugin_options' );
    if (!isset($_COOKIE['q_cookie']) && $options['token']) {
        setcookie('q_cookie', $options['token'], time() + 86400, '/');
    } else if (isset($_COOKIE['q_cookie']) && !$options['token']){
        unset_cookie('q_cookie');
    }
    return;
}
add_action('admin_menu','set_q_cookie');

// remove cookie
function unset_cookie($key){
    if (isset($_COOKIE[$key])) {
        unset($_COOKIE[$key]);
        setcookie($key, '', time() - 3600, '/');
    }
    return;
}

// clear saved credentials from DB
function clear_client_options(){
    delete_option( 'client_plugin_options' );
    //unset_cookie('q_cookie');
    return;
}

// connect to Q Symfony Skeleton API
function connect_to_q(){
    $options = get_option( 'client_plugin_options' );
    if (!$options){
        return 'Connection unsuccessful! Maybe try again with different credentials?! no_options';
    }
    $url = 'https://symfony-skeleton.q-tests.com/api/v2/token';
    $args = [
        'headers'    => [
            'Content-Type' => 'application/json',
            'accept' => 'application/json',
        ],
        'body' => json_encode([
            'email' => $options['email'], //'ahsoka.tano@q.agency',
            'password' => $options['password'], //'Kryze4President'
        ]),
        'method'    => 'POST',
        //'user-agent' => self::ua
    ]; // 'timeout'    => 5
 

    $response = wp_remote_post(
        $url, $args
    );
    if ($response instanceof \WP_Error) {
        // return '<div style="color:red; font-weight:bold;">Connection unsuccessful! Maybe try again with different credentials?!</div>';
        wp_die($response, 'Error');
    }

    $res =  json_decode($response['body'], true);
    if ($res['errors']) {
        clear_client_options();
        return $res['token_key'];
    } else {        
        //setcookie('q_cookie', $res['token_key'], time() + 86400, '/');
        $options = get_option( 'client_plugin_options' );
        $options['token'] = $res['token_key'];
        update_option('client_plugin_options', $options, true);
        return '<br /><div style="display:inline-block; margin-right:auto; color:green; padding: 20px; border:2px solid green; margin-top:30px;">Your token is: <strong>'.$res['token_key'].'</strong></div>';
    }
}

// display the settings form
function client_render_plugin_settings_page() {

    $options = get_option( 'client_plugin_options' );

    if($_GET['reset']){
        if( $_GET['reset'] == 'true' &&  $options){
            clear_client_options();/*
            wp_redirect( site_url().'/wp-admin/options-general.php?page=client-plugin' );
            exit;*/
        }
    }

    $q_cookie = ''; // token cookie
    $reset = '';//<br /><br /><a href="'.site_url().'/wp-admin/options-general.php?page=client-plugin&reset=true">Re-enter credentials</a>';
    if (isset($_COOKIE['q_cookie']) && $options['token']){
        // already logged in
        $q_cookie = $_COOKIE['q_cookie'];
        echo '<div><br />You are connected to <strong>Q Symfony Skeleton API</strong></div>'.
            $reset.'
            <div style="display:inline-block; margin-right:auto; color:green; padding: 20px; border:2px solid green; margin-top:30px;">Your token is: <strong>'.$q_cookie.'</strong></div>';
    } else if( $options && !( esc_attr( $options['password']) && esc_attr( $options['email'] ) ) ){
        // credentials submitted, but not both fields filled-in
        echo '<strong style="color:red; display:block;">Check your credentials and try again.<br />
            Both fields are mandatory!</strong>';
    } else if( !isset($_COOKIE['q_cookie']) && $options && esc_attr( $options['password']) && esc_attr( $options['email'] ) ){
        // credentials submitted, checking if valid
        $api_resp = connect_to_q();
        if ($api_resp){
            //wp_redirect( site_url().'/wp-admin/options-general.php?page=client-plugin' );
            echo '<script>window.location.reload()</script>';
        } else {
            echo '<div style="color:red; font-weight:bold;">Connection unsuccessful! Maybe try again with different credentials?!</div>';
        }
    }
    // the form
    ?>
    <form action="options.php" method="post" name="plgn_sett">
        <?php 
        settings_fields( 'client_plugin_options' );        // output fields ('option group')
        do_settings_sections( 'client_plugin' );           // print section ('page') ?>
        <input name="submit" class="button button-primary" type="submit" value="<?php esc_attr_e( 'Connect' ); ?>" />
    </form>
    <?php
    if ($options){
        echo $reset;
    }
}

// define new wp_options
function client_register_settings() {

    register_setting( 
        'client_plugin_options',               // option group
        'client_plugin_options',               // option name
        //'client_plugin_options_validate',      // $args sanitize_callback
    );

    add_settings_section(       
        'client_settings',             // id
        'Client Settings',             // Title
        'client_plugin_section_text',  // subheader txt
        'client_plugin' );     // slug/name of the page
        
    add_settings_field(
        'client_plugin_setting_email',   // id
        'Email',                      // title
        'client_plugin_setting_email',   // callback = input => field
        'client_plugin',           // page
        'client_settings' );               // section
    add_settings_field( 
        'client_plugin_setting_password', 
        'Password', 
        'client_plugin_setting_password', 
        'client_plugin', 
        'client_settings' );
    add_settings_field( 
        'client_plugin_setting_token', 
        '', 
        'client_plugin_setting_token', 
        'client_plugin', 
        'client_settings' );
}
add_action( 'admin_init', 'client_register_settings' );     // fires 2nd (after admin_menu)

function client_plugin_section_text() {
    echo '<p>Please enter email and password to connect:</p>';
}

function client_plugin_setting_email() {
    echo "<input id='client_plugin_setting_email' name='client_plugin_options[email]' type='text' value='' />";
}

function client_plugin_setting_password() {
    echo "<input id='client_plugin_setting_password' name='client_plugin_options[password]' type='password' value='' />";
}

function client_plugin_setting_token() {
    echo "<input id='client_plugin_setting_token' name='client_plugin_options[token]' type='hidden' value='' />";
}

?>